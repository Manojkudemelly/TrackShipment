import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Calendar, Clock, AlertCircle } from "lucide-react";

const AssetRequest = () => {
  const [formData, setFormData] = useState({
    region: "",
    country: "",
    driverEmail: "",
    operationsLead: ""
  });

  // Mock pending requests data
  const pendingRequests = [
    {
      id: "REQ-001245",
      date: "2024-01-29",
      requester: "John Smith",
      region: "North America",
      country: "USA",
      driverEmail: "driver1@company.com",
      opsLead: "lead1@company.com",
      status: "Pending",
      delayDays: 0
    },
    {
      id: "REQ-001244",
      date: "2024-01-27",
      requester: "Maria Garcia",
      region: "Europe",
      country: "Spain",
      driverEmail: "driver2@company.com",
      opsLead: "lead2@company.com",
      status: "Pending",
      delayDays: 2
    },
    {
      id: "REQ-001243",
      date: "2024-01-25",
      requester: "Chen Wei",
      region: "Asia Pacific",
      country: "China",
      driverEmail: "driver3@company.com",
      opsLead: "lead3@company.com",
      status: "Pending",
      delayDays: 4
    }
  ];

  const handleSubmit = () => {
    // Here you would submit to backend API
    console.log("Submitting request:", formData);
    
    // Reset form
    setFormData({
      region: "",
      country: "",
      driverEmail: "",
      operationsLead: ""
    });
  };

  const getStatusBadge = (delayDays: number) => {
    if (delayDays === 0) {
      return <Badge className="bg-accent text-accent-foreground">On Time</Badge>;
    } else if (delayDays <= 2) {
      return <Badge className="bg-warning text-warning-foreground">Minor Delay</Badge>;
    } else {
      return <Badge className="bg-destructive text-destructive-foreground">Critical Delay</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Asset Request Management</h1>
        <p className="text-muted-foreground">Submit new asset requests and track pending requests</p>
      </div>

      {/* Request Form */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="h-5 w-5" />
            <span>New Asset Request</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Region</label>
              <Select value={formData.region} onValueChange={(value) => setFormData(prev => ({ ...prev, region: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="north-america">North America</SelectItem>
                  <SelectItem value="europe">Europe</SelectItem>
                  <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
                  <SelectItem value="latin-america">Latin America</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Country</label>
              <Select value={formData.country} onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usa">United States</SelectItem>
                  <SelectItem value="uk">United Kingdom</SelectItem>
                  <SelectItem value="germany">Germany</SelectItem>
                  <SelectItem value="spain">Spain</SelectItem>
                  <SelectItem value="china">China</SelectItem>
                  <SelectItem value="japan">Japan</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Driver Email</label>
              <Select value={formData.driverEmail} onValueChange={(value) => setFormData(prev => ({ ...prev, driverEmail: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Driver" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="driver1@company.com">driver1@company.com</SelectItem>
                  <SelectItem value="driver2@company.com">driver2@company.com</SelectItem>
                  <SelectItem value="driver3@company.com">driver3@company.com</SelectItem>
                  <SelectItem value="driver4@company.com">driver4@company.com</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Operations Lead</label>
              <Select value={formData.operationsLead} onValueChange={(value) => setFormData(prev => ({ ...prev, operationsLead: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Lead" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lead1@company.com">lead1@company.com</SelectItem>
                  <SelectItem value="lead2@company.com">lead2@company.com</SelectItem>
                  <SelectItem value="lead3@company.com">lead3@company.com</SelectItem>
                  <SelectItem value="lead4@company.com">lead4@company.com</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleSubmit}
            className="bg-gradient-primary hover:bg-primary-hover transition-smooth"
            disabled={!formData.region || !formData.country || !formData.driverEmail || !formData.operationsLead}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Request
          </Button>
        </CardContent>
      </Card>

      {/* Pending Requests Table */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Pending Requests</span>
            </div>
            <Badge variant="outline" className="bg-muted">
              {pendingRequests.length} Pending
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Request ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Requester</TableHead>
                <TableHead>Region</TableHead>
                <TableHead>Country</TableHead>
                <TableHead>Driver Email</TableHead>
                <TableHead>Operations Lead</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Delay Days</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingRequests.map((request) => (
                <TableRow key={request.id} className="hover:bg-muted/50 transition-smooth">
                  <TableCell className="font-medium">{request.id}</TableCell>
                  <TableCell>{request.date}</TableCell>
                  <TableCell>{request.requester}</TableCell>
                  <TableCell>{request.region}</TableCell>
                  <TableCell>{request.country}</TableCell>
                  <TableCell>{request.driverEmail}</TableCell>
                  <TableCell>{request.opsLead}</TableCell>
                  <TableCell>{getStatusBadge(request.delayDays)}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {request.delayDays > 2 && <AlertCircle className="h-4 w-4 text-destructive" />}
                      <span className={request.delayDays > 2 ? "text-destructive font-medium" : "text-foreground"}>
                        {request.delayDays}
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default AssetRequest;