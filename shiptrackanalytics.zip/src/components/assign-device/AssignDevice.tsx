import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Smartphone, CheckCircle, Clock, AlertTriangle } from "lucide-react";

const AssignDevice = () => {
  const [formData, setFormData] = useState({
    requestId: "",
    region: "",
    country: "",
    driverEmail: "",
    opsLeadEmail: "",
    phoneModel: "",
    imeiNumber: "",
    phoneNumber: ""
  });

  // Mock assignment data
  const assignments = [
    {
      id: "REQ-001245",
      date: "2024-01-29",
      requester: "John Smith",
      region: "North America",
      country: "USA",
      driverEmail: "driver1@company.com",
      opsLead: "lead1@company.com",
      status: "Assigned",
      action: "Completed",
      delayDays: 0
    },
    {
      id: "REQ-001244",
      date: "2024-01-27",
      requester: "Maria Garcia",
      region: "Europe",
      country: "Spain",
      driverEmail: "driver2@company.com",
      opsLead: "lead2@company.com",
      status: "In Progress",
      action: "Pending",
      delayDays: 2
    },
    {
      id: "REQ-001243",
      date: "2024-01-25",
      requester: "Chen Wei",
      region: "Asia Pacific",
      country: "China",
      driverEmail: "driver3@company.com",
      opsLead: "lead3@company.com",
      status: "Failed",
      action: "Retry Required",
      delayDays: 4
    }
  ];

  const handleAssign = () => {
    console.log("Assigning device:", formData);
    
    // Reset form
    setFormData({
      requestId: "",
      region: "",
      country: "",
      driverEmail: "",
      opsLeadEmail: "",
      phoneModel: "",
      imeiNumber: "",
      phoneNumber: ""
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Assigned":
        return <Badge className="bg-accent text-accent-foreground">Assigned</Badge>;
      case "In Progress":
        return <Badge className="bg-primary text-primary-foreground">In Progress</Badge>;
      case "Failed":
        return <Badge className="bg-destructive text-destructive-foreground">Failed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Device Assignment</h1>
        <p className="text-muted-foreground">Assign devices to pending requests and track assignments</p>
      </div>

      {/* Assignment Form */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Smartphone className="h-5 w-5" />
            <span>Assign Device</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Request ID</label>
              <Select value={formData.requestId} onValueChange={(value) => setFormData(prev => ({ ...prev, requestId: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Request" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="REQ-001245">REQ-001245</SelectItem>
                  <SelectItem value="REQ-001244">REQ-001244</SelectItem>
                  <SelectItem value="REQ-001243">REQ-001243</SelectItem>
                  <SelectItem value="REQ-001242">REQ-001242</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Region</label>
              <Select value={formData.region} onValueChange={(value) => setFormData(prev => ({ ...prev, region: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="north-america">North America</SelectItem>
                  <SelectItem value="europe">Europe</SelectItem>
                  <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
                  <SelectItem value="latin-america">Latin America</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Country</label>
              <Select value={formData.country} onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usa">United States</SelectItem>
                  <SelectItem value="uk">United Kingdom</SelectItem>
                  <SelectItem value="germany">Germany</SelectItem>
                  <SelectItem value="spain">Spain</SelectItem>
                  <SelectItem value="china">China</SelectItem>
                  <SelectItem value="japan">Japan</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Driver Email</label>
              <Select value={formData.driverEmail} onValueChange={(value) => setFormData(prev => ({ ...prev, driverEmail: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Driver" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="driver1@company.com">driver1@company.com</SelectItem>
                  <SelectItem value="driver2@company.com">driver2@company.com</SelectItem>
                  <SelectItem value="driver3@company.com">driver3@company.com</SelectItem>
                  <SelectItem value="driver4@company.com">driver4@company.com</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Operations Lead Email</label>
              <Select value={formData.opsLeadEmail} onValueChange={(value) => setFormData(prev => ({ ...prev, opsLeadEmail: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Ops Lead" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lead1@company.com">lead1@company.com</SelectItem>
                  <SelectItem value="lead2@company.com">lead2@company.com</SelectItem>
                  <SelectItem value="lead3@company.com">lead3@company.com</SelectItem>
                  <SelectItem value="lead4@company.com">lead4@company.com</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Phone Model</label>
              <Select value={formData.phoneModel} onValueChange={(value) => setFormData(prev => ({ ...prev, phoneModel: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="iphone-14">iPhone 14</SelectItem>
                  <SelectItem value="iphone-13">iPhone 13</SelectItem>
                  <SelectItem value="samsung-s23">Samsung Galaxy S23</SelectItem>
                  <SelectItem value="samsung-s22">Samsung Galaxy S22</SelectItem>
                  <SelectItem value="pixel-7">Google Pixel 7</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">IMEI Number</label>
              <Input
                placeholder="Enter IMEI"
                value={formData.imeiNumber}
                onChange={(e) => setFormData(prev => ({ ...prev, imeiNumber: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Phone Number</label>
              <Input
                placeholder="Enter phone number"
                value={formData.phoneNumber}
                onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
              />
            </div>
          </div>

          <Button 
            onClick={handleAssign}
            className="bg-gradient-primary hover:bg-primary-hover transition-smooth"
          >
            <Smartphone className="h-4 w-4 mr-2" />
            Assign Device
          </Button>
        </CardContent>
      </Card>

      {/* Assignments Table */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5" />
              <span>Device Assignments</span>
            </div>
            <Badge variant="outline" className="bg-muted">
              {assignments.length} Assignments
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Request ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Requester</TableHead>
                <TableHead>Region</TableHead>
                <TableHead>Country</TableHead>
                <TableHead>Driver Email</TableHead>
                <TableHead>Ops Lead</TableHead>
                <TableHead>Assign Status</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Delay Days</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id} className="hover:bg-muted/50 transition-smooth">
                  <TableCell className="font-medium">{assignment.id}</TableCell>
                  <TableCell>{assignment.date}</TableCell>
                  <TableCell>{assignment.requester}</TableCell>
                  <TableCell>{assignment.region}</TableCell>
                  <TableCell>{assignment.country}</TableCell>
                  <TableCell>{assignment.driverEmail}</TableCell>
                  <TableCell>{assignment.opsLead}</TableCell>
                  <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                  <TableCell>
                    <span className={assignment.action === "Completed" ? "text-accent font-medium" : "text-muted-foreground"}>
                      {assignment.action}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {assignment.delayDays > 2 && <AlertTriangle className="h-4 w-4 text-destructive" />}
                      <span className={assignment.delayDays > 2 ? "text-destructive font-medium" : "text-foreground"}>
                        {assignment.delayDays}
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default AssignDevice;