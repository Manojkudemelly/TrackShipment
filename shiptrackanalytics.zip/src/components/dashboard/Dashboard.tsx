import { useState, useMemo } from "react";
import { Package, Car, ShieldOff, Clock, CheckCircle, XCircle, Timer, Calendar, Warehouse, TrendingUp, TrendingDown, Users, MapPin, BarChart3 } from "lucide-react";
import MetricCard from "./MetricCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Regional data structure with metrics by region and country
const regionalData = {
  "all-regions": {
    name: "All Regions",
    countries: {
      "all-countries": {
        name: "All Countries",
        metrics: {
          totalInventory: 15420,
          activeInventory: 12850,
          damagedInventory: 2570,
          inventoryWithDrivers: 8600,
          idleInventory: 4250,
          totalWaitList: 156,
          waitListUnder2Days: 89,
          waitListOver2Days: 67
        }
      }
    }
  },
  "north-america": {
    name: "North America",
    countries: {
      "all-countries": {
        name: "All Countries",
        metrics: {
          totalInventory: 6800,
          activeInventory: 5950,
          damagedInventory: 850,
          inventoryWithDrivers: 4200,
          idleInventory: 1750,
          totalWaitList: 45,
          waitListUnder2Days: 28,
          waitListOver2Days: 17
        }
      },
      "usa": {
        name: "United States",
        metrics: {
          totalInventory: 5200,
          activeInventory: 4550,
          damagedInventory: 650,
          inventoryWithDrivers: 3200,
          idleInventory: 1350,
          totalWaitList: 32,
          waitListUnder2Days: 20,
          waitListOver2Days: 12
        }
      },
      "canada": {
        name: "Canada",
        metrics: {
          totalInventory: 1600,
          activeInventory: 1400,
          damagedInventory: 200,
          inventoryWithDrivers: 1000,
          idleInventory: 400,
          totalWaitList: 13,
          waitListUnder2Days: 8,
          waitListOver2Days: 5
        }
      }
    }
  },
  "europe": {
    name: "Europe",
    countries: {
      "all-countries": {
        name: "All Countries",
        metrics: {
          totalInventory: 4200,
          activeInventory: 3680,
          damagedInventory: 520,
          inventoryWithDrivers: 2400,
          idleInventory: 1280,
          totalWaitList: 38,
          waitListUnder2Days: 22,
          waitListOver2Days: 16
        }
      },
      "uk": {
        name: "United Kingdom",
        metrics: {
          totalInventory: 1800,
          activeInventory: 1580,
          damagedInventory: 220,
          inventoryWithDrivers: 1100,
          idleInventory: 480,
          totalWaitList: 18,
          waitListUnder2Days: 11,
          waitListOver2Days: 7
        }
      },
      "germany": {
        name: "Germany",
        metrics: {
          totalInventory: 1500,
          activeInventory: 1320,
          damagedInventory: 180,
          inventoryWithDrivers: 850,
          idleInventory: 470,
          totalWaitList: 12,
          waitListUnder2Days: 7,
          waitListOver2Days: 5
        }
      },
      "spain": {
        name: "Spain",
        metrics: {
          totalInventory: 900,
          activeInventory: 780,
          damagedInventory: 120,
          inventoryWithDrivers: 450,
          idleInventory: 330,
          totalWaitList: 8,
          waitListUnder2Days: 4,
          waitListOver2Days: 4
        }
      }
    }
  },
  "asia-pacific": {
    name: "Asia Pacific",
    countries: {
      "all-countries": {
        name: "All Countries",
        metrics: {
          totalInventory: 3100,
          activeInventory: 2540,
          damagedInventory: 560,
          inventoryWithDrivers: 1600,
          idleInventory: 940,
          totalWaitList: 52,
          waitListUnder2Days: 25,
          waitListOver2Days: 27
        }
      },
      "china": {
        name: "China",
        metrics: {
          totalInventory: 1800,
          activeInventory: 1480,
          damagedInventory: 320,
          inventoryWithDrivers: 950,
          idleInventory: 530,
          totalWaitList: 28,
          waitListUnder2Days: 12,
          waitListOver2Days: 16
        }
      },
      "japan": {
        name: "Japan",
        metrics: {
          totalInventory: 1300,
          activeInventory: 1060,
          damagedInventory: 240,
          inventoryWithDrivers: 650,
          idleInventory: 410,
          totalWaitList: 24,
          waitListUnder2Days: 13,
          waitListOver2Days: 11
        }
      }
    }
  },
  "latin-america": {
    name: "Latin America",
    countries: {
      "all-countries": {
        name: "All Countries",
        metrics: {
          totalInventory: 1320,
          activeInventory: 680,
          damagedInventory: 640,
          inventoryWithDrivers: 400,
          idleInventory: 280,
          totalWaitList: 21,
          waitListUnder2Days: 14,
          waitListOver2Days: 7
        }
      },
      "brazil": {
        name: "Brazil",
        metrics: {
          totalInventory: 800,
          activeInventory: 420,
          damagedInventory: 380,
          inventoryWithDrivers: 250,
          idleInventory: 170,
          totalWaitList: 13,
          waitListUnder2Days: 9,
          waitListOver2Days: 4
        }
      },
      "mexico": {
        name: "Mexico",
        metrics: {
          totalInventory: 520,
          activeInventory: 260,
          damagedInventory: 260,
          inventoryWithDrivers: 150,
          idleInventory: 110,
          totalWaitList: 8,
          waitListUnder2Days: 5,
          waitListOver2Days: 3
        }
      }
    }
  }
};

const Dashboard = () => {
  const [selectedRegion, setSelectedRegion] = useState("all-regions");
  const [selectedCountry, setSelectedCountry] = useState("all-countries");

  // Get available countries for selected region
  const availableCountries = useMemo(() => {
    if (selectedRegion === "all-regions") {
      // When "All Regions" is selected, show all countries from all regions
      const allCountries = [{ value: "all-countries", label: "All Countries" }];
      
      Object.entries(regionalData).forEach(([regionKey, region]) => {
        if (regionKey !== "all-regions") {
          Object.entries(region.countries).forEach(([countryKey, country]) => {
            if (countryKey !== "all-countries") {
              allCountries.push({
                value: countryKey,
                label: country.name
              });
            }
          });
        }
      });
      
      return allCountries;
    }
    
    const region = regionalData[selectedRegion as keyof typeof regionalData];
    if (!region) return [{ value: "all-countries", label: "All Countries" }];
    
    return Object.entries(region.countries).map(([key, country]) => ({
      value: key,
      label: country.name
    }));
  }, [selectedRegion]);

  // Get current metrics based on selected region and country
  const metrics = useMemo(() => {
    if (selectedRegion === "all-regions") {
      if (selectedCountry === "all-countries") {
        return regionalData["all-regions"].countries["all-countries"].metrics;
      } else {
        // Find the country in any region when "All Regions" is selected
        for (const [regionKey, region] of Object.entries(regionalData)) {
          if (regionKey !== "all-regions") {
            const country = region.countries[selectedCountry as keyof typeof region.countries];
            if (country) {
              return country.metrics;
            }
          }
        }
        // Fallback to all regions if country not found
        return regionalData["all-regions"].countries["all-countries"].metrics;
      }
    }
    
    const region = regionalData[selectedRegion as keyof typeof regionalData];
    if (!region) return regionalData["all-regions"].countries["all-countries"].metrics;
    
    const country = region.countries[selectedCountry as keyof typeof region.countries];
    if (!country) {
      // If selected country not available, use "all-countries" for the region
      return region.countries["all-countries"].metrics;
    }
    
    return country.metrics;
  }, [selectedRegion, selectedCountry]);

  // Reset country selection when region changes
  const handleRegionChange = (newRegion: string) => {
    setSelectedRegion(newRegion);
    setSelectedCountry("all-countries");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Shipment Dashboard</h1>
          <p className="text-muted-foreground">Monitor your shipping operations and inventory metrics</p>
        </div>
        
        <div className="flex space-x-4">
          <Select value={selectedRegion} onValueChange={handleRegionChange}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-regions">All Regions</SelectItem>
              <SelectItem value="north-america">North America</SelectItem>
              <SelectItem value="europe">Europe</SelectItem>
              <SelectItem value="asia-pacific">Asia Pacific</SelectItem>
              <SelectItem value="latin-america">Latin America</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedCountry} onValueChange={setSelectedCountry}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select Country" />
            </SelectTrigger>
            <SelectContent>
              {availableCountries.map((country) => (
                <SelectItem key={country.value} value={country.value}>
                  {country.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Inventory Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Inventory"
          value={metrics.totalInventory}
          icon={Package}
          variant="accent"
          trend={{ value: 12.5, isPositive: true }}
          tooltip={{
            description: "Sum of all inventory items across all locations and statuses",
            formula: "Active Inventory + Damaged Inventory",
            parameters: [
              "Active Inventory: Currently operational items",
              "Damaged Inventory: Non-functional items requiring repair/replacement",
              "Includes items with drivers and idle inventory"
            ]
          }}
        />
        <MetricCard
          title="Active Inventory"
          value={metrics.activeInventory}
          icon={CheckCircle}
          trend={{ value: 8.2, isPositive: true }}
          tooltip={{
            description: "Total number of functional inventory items ready for use",
            formula: "Inventory with Drivers + Idle Inventory",
            parameters: [
              "Inventory with Drivers: Items currently assigned to drivers",
              "Idle Inventory: Items in warehouse/stock ready for assignment",
              "Excludes damaged or non-functional items"
            ]
          }}
        />
        <MetricCard
          title="Damaged Inventory"
          value={metrics.damagedInventory}
          icon={ShieldOff}
          variant="warning"
          trend={{ value: -3.1, isPositive: false }}
          tooltip={{
            description: "Items that are non-functional and require repair or replacement",
            formula: "Count of items with status = 'Damaged' or 'Lost'",
            parameters: [
              "Damaged: Items requiring repair",
              "Lost: Items that cannot be located",
              "Stolen: Items reported as theft",
              "Beyond Repair: Items requiring replacement"
            ]
          }}
        />
        <MetricCard
          title="Inventory with Drivers"
          value={metrics.inventoryWithDrivers}
          icon={Car}
          trend={{ value: 15.7, isPositive: true }}
          tooltip={{
            description: "Number of items currently assigned and in use by drivers",
            formula: "Count of items with assignment_status = 'Active' AND driver_id IS NOT NULL",
            parameters: [
              "Active assignments only",
              "Driver must be verified and active",
              "Item must be functional",
              "Assignment date within active period"
            ]
          }}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Idle Inventory"
          value={metrics.idleInventory}
          icon={Warehouse}
          trend={{ value: -5.2, isPositive: false }}
          tooltip={{
            description: "Functional items available in stock but not currently assigned",
            formula: "Active Inventory - Inventory with Drivers",
            parameters: [
              "Items in warehouse/depot",
              "Ready for immediate assignment",
              "Quality checked and functional",
              "No pending assignments or requests"
            ]
          }}
        />
        <MetricCard
          title="Total Wait List"
          value={metrics.totalWaitList}
          icon={Clock}
          variant="destructive"
          tooltip={{
            description: "Total number of pending requests awaiting device assignment",
            formula: "Wait List < 2 Days + Wait List ≥ 2 Days",
            parameters: [
              "Pending asset requests",
              "Approved requests awaiting fulfillment",
              "Requests with valid driver information",
              "Excludes cancelled or completed requests"
            ]
          }}
        />
        <MetricCard
          title="Wait List < 2 Days"
          value={metrics.waitListUnder2Days}
          icon={Timer}
          trend={{ value: 22.8, isPositive: true }}
          tooltip={{
            description: "Requests submitted within the last 2 days and still pending",
            formula: "Count of requests WHERE (current_date - request_date) < 2 AND status = 'Pending'",
            parameters: [
              "Request date within last 48 hours",
              "Status must be 'Pending' or 'Approved'",
              "Business days calculation",
              "Excludes weekends and holidays"
            ]
          }}
        />
        <MetricCard
          title="Wait List ≥ 2 Days"
          value={metrics.waitListOver2Days}
          icon={Calendar}
          variant="warning"
          trend={{ value: -18.5, isPositive: false }}
          tooltip={{
            description: "Requests older than 2 days that are still pending - requires priority attention",
            formula: "Count of requests WHERE (current_date - request_date) >= 2 AND status = 'Pending'",
            parameters: [
              "Request date 2+ business days ago",
              "High priority for processing",
              "May indicate inventory shortage",
              "SLA breach indicator"
            ]
          }}
        />
      </div>

      {/* Enhanced Regional Performance - Full Width */}
      <Card className="shadow-large animate-slide-up">
        <CardHeader className="bg-gradient-primary text-white rounded-t-lg">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BarChart3 className="h-6 w-6" />
              <div>
                <h2 className="text-2xl font-bold">
                  {selectedRegion === "all-regions" ? "Global Performance Overview" : 
                   selectedCountry === "all-countries" ? `${regionalData[selectedRegion as keyof typeof regionalData]?.name} Performance` : 
                   "Detailed Analytics"}
                </h2>
                <p className="text-white/80 text-sm">
                  Comprehensive metrics and insights at a glance
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-white/80" />
              <span className="text-white/90 font-medium">
                {selectedRegion === "all-regions" ? "All Regions" : regionalData[selectedRegion as keyof typeof regionalData]?.name}
              </span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {selectedRegion === "all-regions" ? (
            // Enhanced Global View - All Regions
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
              {Object.entries(regionalData)
                .filter(([key]) => key !== "all-regions")
                .map(([key, region], index) => {
                  const regionMetrics = region.countries["all-countries"].metrics;
                  const activeRate = ((regionMetrics.activeInventory / regionMetrics.totalInventory) * 100);
                  const waitListCritical = regionMetrics.waitListOver2Days > 0;
                  const damageRate = ((regionMetrics.damagedInventory / regionMetrics.totalInventory) * 100);
                  
                  return (
                    <div 
                      key={key} 
                      className="bg-gradient-subtle border border-border rounded-xl p-6 shadow-soft hover:shadow-medium transition-all duration-300 animate-fade-in"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-bold text-foreground flex items-center space-x-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          <span>{region.name}</span>
                        </h3>
                        <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                          activeRate >= 85 ? "bg-accent/10 text-accent" :
                          activeRate >= 75 ? "bg-warning/10 text-warning" : "bg-destructive/10 text-destructive"
                        }`}>
                          {activeRate.toFixed(1)}% Active
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        {/* Total Inventory */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Package className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">Total Inventory</span>
                          </div>
                          <span className="font-bold text-foreground">{regionMetrics.totalInventory.toLocaleString()}</span>
                        </div>
                        
                        {/* Active vs Idle */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Car className="h-4 w-4 text-accent" />
                              <span className="text-sm text-muted-foreground">With Drivers</span>
                            </div>
                            <span className="font-medium text-foreground">{regionMetrics.inventoryWithDrivers.toLocaleString()}</span>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Warehouse className="h-4 w-4 text-primary" />
                              <span className="text-sm text-muted-foreground">In Storage</span>
                            </div>
                            <span className="font-medium text-foreground">{regionMetrics.idleInventory.toLocaleString()}</span>
                          </div>
                        </div>
                        
                        {/* Issues Section */}
                        <div className="border-t border-border pt-3">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <ShieldOff className="h-4 w-4 text-warning" />
                              <span className="text-sm text-muted-foreground">Damaged</span>
                            </div>
                            <div className="text-right">
                              <span className="font-medium text-foreground">{regionMetrics.damagedInventory.toLocaleString()}</span>
                              <div className="text-xs text-muted-foreground">{damageRate.toFixed(1)}%</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Clock className={`h-4 w-4 ${waitListCritical ? "text-destructive" : "text-muted-foreground"}`} />
                              <span className="text-sm text-muted-foreground">Wait List</span>
                            </div>
                            <div className="text-right">
                              <span className={`font-medium ${waitListCritical ? "text-destructive" : "text-foreground"}`}>
                                {regionMetrics.totalWaitList}
                              </span>
                              {waitListCritical && (
                                <div className="text-xs text-destructive">{regionMetrics.waitListOver2Days} critical</div>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        {/* Performance Indicator */}
                        <div className="border-t border-border pt-3">
                          <div className="flex items-center space-x-2 mb-2">
                            <TrendingUp className={`h-4 w-4 ${activeRate >= 85 ? "text-accent" : "text-muted-foreground"}`} />
                            <span className="text-sm font-medium text-foreground">Performance</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full transition-all duration-500 ${
                                activeRate >= 85 ? "bg-accent" :
                                activeRate >= 75 ? "bg-warning" : "bg-destructive"
                              }`}
                              style={{ width: `${Math.min(activeRate, 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : selectedCountry === "all-countries" ? (
            // Enhanced Region View - Countries within selected region
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gradient-accent text-white p-4 rounded-lg shadow-soft">
                  <div className="flex items-center space-x-3">
                    <Users className="h-8 w-8" />
                    <div>
                      <div className="text-2xl font-bold">{metrics.totalInventory.toLocaleString()}</div>
                      <div className="text-white/80 text-sm">Total Region Inventory</div>
                    </div>
                  </div>
                </div>
                <div className="bg-card border border-border p-4 rounded-lg shadow-soft">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-8 w-8 text-accent" />
                    <div>
                      <div className="text-2xl font-bold text-foreground">{((metrics.activeInventory / metrics.totalInventory) * 100).toFixed(1)}%</div>
                      <div className="text-muted-foreground text-sm">Active Rate</div>
                    </div>
                  </div>
                </div>
                <div className="bg-card border border-border p-4 rounded-lg shadow-soft">
                  <div className="flex items-center space-x-3">
                    <Clock className="h-8 w-8 text-warning" />
                    <div>
                      <div className="text-2xl font-bold text-foreground">{metrics.totalWaitList}</div>
                      <div className="text-muted-foreground text-sm">Pending Requests</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {Object.entries(regionalData[selectedRegion as keyof typeof regionalData].countries)
                  .filter(([key]) => key !== "all-countries")
                  .map(([key, country], index) => {
                    const activeRate = ((country.metrics.activeInventory / country.metrics.totalInventory) * 100);
                    const waitListCritical = country.metrics.waitListOver2Days > 0;
                    
                    return (
                      <div 
                        key={key} 
                        className="bg-card border border-border rounded-lg p-5 shadow-soft hover:shadow-medium transition-all duration-300 animate-scale-in"
                        style={{ animationDelay: `${index * 0.15}s` }}
                      >
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-lg font-bold text-foreground">{country.name}</h4>
                          <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                            activeRate >= 85 ? "bg-accent/10 text-accent" :
                            activeRate >= 75 ? "bg-warning/10 text-warning" : "bg-destructive/10 text-destructive"
                          }`}>
                            {activeRate.toFixed(1)}%
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <div className="text-muted-foreground">Total</div>
                            <div className="font-bold text-foreground">{country.metrics.totalInventory.toLocaleString()}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Active</div>
                            <div className="font-bold text-accent">{country.metrics.activeInventory.toLocaleString()}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Damaged</div>
                            <div className="font-bold text-warning">{country.metrics.damagedInventory.toLocaleString()}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Wait List</div>
                            <div className={`font-bold ${waitListCritical ? "text-destructive" : "text-foreground"}`}>
                              {country.metrics.totalWaitList}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          ) : (
            // Enhanced Country View - Detailed single country
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gradient-primary text-white p-4 rounded-lg shadow-soft">
                  <div className="text-center">
                    <Package className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">{metrics.totalInventory.toLocaleString()}</div>
                    <div className="text-white/80 text-sm">Total Inventory</div>
                  </div>
                </div>
                <div className="bg-gradient-accent text-white p-4 rounded-lg shadow-soft">
                  <div className="text-center">
                    <CheckCircle className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">{metrics.activeInventory.toLocaleString()}</div>
                    <div className="text-white/80 text-sm">Active Items</div>
                  </div>
                </div>
                <div className="bg-warning text-white p-4 rounded-lg shadow-soft">
                  <div className="text-center">
                    <ShieldOff className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">{metrics.damagedInventory.toLocaleString()}</div>
                    <div className="text-white/80 text-sm">Damaged</div>
                  </div>
                </div>
                <div className="bg-destructive text-white p-4 rounded-lg shadow-soft">
                  <div className="text-center">
                    <Clock className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">{metrics.totalWaitList}</div>
                    <div className="text-white/80 text-sm">Wait List</div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-soft">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Car className="h-5 w-5" />
                      <span>Deployment Status</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">With Drivers</span>
                        <span className="font-bold text-foreground">{metrics.inventoryWithDrivers.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">In Storage</span>
                        <span className="font-bold text-foreground">{metrics.idleInventory.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-3">
                        <div 
                          className="bg-accent h-3 rounded-full transition-all duration-500"
                          style={{ width: `${(metrics.inventoryWithDrivers / metrics.activeInventory) * 100}%` }}
                        />
                      </div>
                      <div className="text-center text-sm text-muted-foreground">
                        {((metrics.inventoryWithDrivers / metrics.activeInventory) * 100).toFixed(1)}% deployed
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="shadow-soft">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Timer className="h-5 w-5" />
                      <span>Request Status</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Under 2 Days</span>
                        <span className="font-bold text-accent">{metrics.waitListUnder2Days}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Over 2 Days</span>
                        <span className="font-bold text-destructive">{metrics.waitListOver2Days}</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-3">
                        <div 
                          className="bg-destructive h-3 rounded-full transition-all duration-500"
                          style={{ width: `${metrics.totalWaitList > 0 ? (metrics.waitListOver2Days / metrics.totalWaitList) * 100 : 0}%` }}
                        />
                      </div>
                      <div className="text-center text-sm text-muted-foreground">
                        {metrics.totalWaitList > 0 ? ((metrics.waitListOver2Days / metrics.totalWaitList) * 100).toFixed(1) : 0}% critical
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Recent Activity - Now below the enhanced regional section */}
      <Card className="shadow-soft animate-fade-in">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5" />
            <span>Recent Activity</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { action: "Device Assigned", count: 45, time: "2 hours ago", type: "success", icon: CheckCircle },
              { action: "Status Modified", count: 12, time: "4 hours ago", type: "info", icon: Users },
              { action: "Asset Requested", count: 23, time: "6 hours ago", type: "warning", icon: Package },
              { action: "Device Damaged", count: 8, time: "8 hours ago", type: "error", icon: ShieldOff },
            ].map((item, index) => {
              const Icon = item.icon;
              return (
                <div 
                  key={index} 
                  className="flex items-center space-x-3 p-4 bg-muted/50 rounded-lg hover:bg-muted/80 transition-all duration-300 animate-scale-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className={`p-2 rounded-full ${
                    item.type === "success" ? "bg-accent/10" :
                    item.type === "info" ? "bg-primary/10" :
                    item.type === "warning" ? "bg-warning/10" : "bg-destructive/10"
                  }`}>
                    <Icon className={`h-5 w-5 ${
                      item.type === "success" ? "text-accent" :
                      item.type === "info" ? "text-primary" :
                      item.type === "warning" ? "text-warning" : "text-destructive"
                    }`} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-foreground">{item.action}</div>
                    <div className="text-sm text-muted-foreground">{item.count} items • {item.time}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;