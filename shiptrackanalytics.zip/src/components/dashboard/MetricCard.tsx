import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Info } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  variant?: "default" | "accent" | "warning" | "destructive";
  trend?: {
    value: number;
    isPositive: boolean;
  };
  tooltip?: {
    formula: string;
    parameters: string[];
    description: string;
  };
}

const MetricCard = ({ title, value, icon: Icon, variant = "default", trend, tooltip }: MetricCardProps) => {
  const getVariantStyles = () => {
    switch (variant) {
      case "accent":
        return "border-accent/20 bg-gradient-accent text-white";
      case "warning":
        return "border-warning/20 bg-warning text-white";
      case "destructive":
        return "border-destructive/20 bg-destructive text-white";
      default:
        return "border-border bg-card text-card-foreground";
    }
  };

  return (
    <TooltipProvider>
      <Card className={cn("shadow-soft transition-smooth hover:shadow-medium", getVariantStyles())}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="flex items-center space-x-2">
            <CardTitle className={cn(
              "text-sm font-medium",
              variant !== "default" ? "text-white/90" : "text-muted-foreground"
            )}>
              {title}
            </CardTitle>
            {tooltip && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className={cn(
                    "h-3 w-3 cursor-help opacity-70 hover:opacity-100 transition-opacity",
                    variant !== "default" ? "text-white/70" : "text-muted-foreground"
                  )} />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs p-4 bg-card border border-border shadow-large">
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-foreground mb-1">Description</h4>
                      <p className="text-sm text-muted-foreground">{tooltip.description}</p>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-foreground mb-1">Formula</h4>
                      <code className="text-xs bg-muted px-2 py-1 rounded font-mono text-foreground">
                        {tooltip.formula}
                      </code>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-foreground mb-1">Parameters</h4>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        {tooltip.parameters.map((param, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-primary mr-1">•</span>
                            <span>{param}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          <Icon className={cn(
            "h-4 w-4",
            variant !== "default" ? "text-white/80" : "text-muted-foreground"
          )} />
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <div className={cn(
              "text-2xl font-bold",
              variant !== "default" ? "text-white" : "text-foreground"
            )}>
              {value.toLocaleString()}
            </div>
            {trend && (
              <div className={cn(
                "text-xs px-2 py-1 rounded-full",
                trend.isPositive 
                  ? variant !== "default" 
                    ? "bg-white/20 text-white" 
                    : "bg-accent/10 text-accent"
                  : variant !== "default"
                    ? "bg-white/20 text-white"
                    : "bg-destructive/10 text-destructive"
              )}>
                {trend.isPositive ? "+" : ""}{trend.value}%
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default MetricCard;