import { Smartphone, CreditCard, Car, TrendingUp } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-gradient-primary shadow-soft border-b border-border">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative bg-white/20 p-2 rounded-lg overflow-hidden">
              {/* Stylish layered logo: car climbing mountain as backdrop, phone and SIM in slanted arrangement */}
              <div className="relative w-8 h-8">
                <Car className="h-7 w-7 text-white/30 absolute -bottom-1 -left-1 transform rotate-[25deg] z-0" />
                <Smartphone className="h-6 w-6 text-white absolute top-0 left-0 transform rotate-12 z-20" />
                <CreditCard className="h-4 w-4 text-white/80 absolute bottom-0 right-0 transform -rotate-12 z-10" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">ShipTrack Analytics</h1>
              <p className="text-white/80 text-sm">Shipment Monitoring & Analytics Platform</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-lg">
            <TrendingUp className="h-4 w-4 text-white" />
            <span className="text-white text-sm font-medium">Live Dashboard</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;