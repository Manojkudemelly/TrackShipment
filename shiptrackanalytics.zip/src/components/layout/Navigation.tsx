import { useState } from "react";
import { Home, Package, Smartphone, Settings, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavigationItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const navigationItems: NavigationItem[] = [
  { id: "dashboard", label: "Dashboard", icon: Home },
  { id: "asset-request", label: "Asset Request", icon: Package },
  { id: "assign-device", label: "Assign Device", icon: Smartphone },
  { id: "modify-status", label: "Modify Status", icon: Settings },
];

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Navigation = ({ activeSection, onSectionChange }: NavigationProps) => {
  return (
    <nav className="bg-card shadow-soft border-r border-border">
      <div className="p-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "w-full flex items-center justify-between px-4 py-3 rounded-lg text-left transition-smooth group",
                    isActive
                      ? "bg-gradient-primary text-white shadow-soft"
                      : "text-foreground hover:bg-secondary hover:text-secondary-foreground"
                  )}
                >
                  <div className="flex items-center space-x-3">
                    <Icon 
                      className={cn(
                        "h-5 w-5 transition-smooth",
                        isActive ? "text-white" : "text-muted-foreground group-hover:text-secondary-foreground"
                      )} 
                    />
                    <span className="font-medium">{item.label}</span>
                  </div>
                  <ChevronRight 
                    className={cn(
                      "h-4 w-4 transition-smooth",
                      isActive ? "text-white opacity-100" : "text-muted-foreground opacity-0 group-hover:opacity-100"
                    )} 
                  />
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};

export default Navigation;