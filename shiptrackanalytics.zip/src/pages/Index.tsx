import { useState } from "react";
import Header from "@/components/layout/Header";
import Navigation from "@/components/layout/Navigation";
import Dashboard from "@/components/dashboard/Dashboard";
import AssetRequest from "@/components/asset-request/AssetRequest";
import AssignDevice from "@/components/assign-device/AssignDevice";
import ModifyStatus from "@/components/modify-status/ModifyStatus";

const Index = () => {
  const [activeSection, setActiveSection] = useState("dashboard");

  const renderActiveSection = () => {
    switch (activeSection) {
      case "dashboard":
        return <Dashboard />;
      case "asset-request":
        return <AssetRequest />;
      case "assign-device":
        return <AssignDevice />;
      case "modify-status":
        return <ModifyStatus />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <Header />
      
      <div className="flex">
        {/* Sidebar Navigation */}
        <div className="w-64 min-h-screen">
          <Navigation 
            activeSection={activeSection} 
            onSectionChange={setActiveSection} 
          />
        </div>
        
        {/* Main Content */}
        <div className="flex-1 p-6">
          {renderActiveSection()}
        </div>
      </div>
    </div>
  );
};

export default Index;
